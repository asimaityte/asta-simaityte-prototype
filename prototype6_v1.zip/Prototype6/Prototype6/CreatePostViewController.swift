//
//  CreatePostViewController.swift
//  Prototype6
//
//  Created by Asta Simaityte on 19/03/2022.
//

import UIKit

class CreatePostViewController: UIViewController {
    
    let textfield:UITextField = UITextField()

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Another view did load.")
        // Get screen width.
        let screenWidth:CGFloat = UIScreen.main.bounds.width
        self.view.backgroundColor = UIColor.blue
        
        textfield.placeholder = "Click to Start typing ...."
        // Set this button's size and location.
        textfield.frame = CGRect(x: 100 , y: 100, width: screenWidth - 2*100, height: 100)
//        textfield.
        textfield.backgroundColor = UIColor.white

        // Create a system default type button.
        let btn:UIButton = UIButton(type: UIButton.ButtonType.system)
        // Define button x, y position value.
        let btnX:CGFloat = 100
        let btnY:CGFloat = 500
        // Set this button's size and location.
        btn.frame = CGRect(x: btnX , y: btnY, width: screenWidth - 2*btnX, height: 30)
        // Set button background color to green.
        btn.backgroundColor = UIColor.green
        // Set button title.
        btn.setTitle("Dismiss This View", for: UIControl.State.normal)
        // Set button title color.
        
        btn.setTitleColor(UIColor.red, for: UIControl.State.normal)
        // Set button text font size.
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        // Add this button touch down event process function.
        btn.addTarget(self, action: #selector(dismissButtonClickEvent(srcObj:)), for: UIControl.Event.touchDown)
        // Add this button to this view.
        self.view.addSubview(btn)
        self.view.addSubview(textfield)
    }
    
    // This function will be called when the button is touch down.
    @objc func dismissButtonClickEvent(srcObj : UIButton) -> Void {
        // It will dismiss thie view object.
        self.dismiss(animated: true, completion: nil)
    }
    
    /* Below method will be invoked when this UIViewController is presented or dismissed. */
    override func viewWillAppear(_ animated: Bool) {
        print("Another view will appear.")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("Another view did appear.")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("Another view will disappear.")
    }
    override func viewDidDisappear(_ animated: Bool) {
        print("Another view did disappear.")
    }
    
    override func didReceiveMemoryWarning() {
        print("Another view receive memory warning.")
    }

}
