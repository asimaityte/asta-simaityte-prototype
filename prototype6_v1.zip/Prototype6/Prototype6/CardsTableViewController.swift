//
//  CardTableViewController.swift
//  Prototype1
//
//  Created by Asta Simaityte on 15/12/2021.
//

import UIKit

protocol TableViewCellDelegate {
    // tell the TableView that a swipe happened
    func hasPerformedSwipe(series: Int, tag: Int)
    func loadCreatePostView(series: Int, tag: Int)
    
}

open class AbstractCardCellAnimation: UITableViewCell {
    private var originalCenter = CGPoint()
    
    func initialize() {
        let recognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePan(recognizer:)))
        recognizer.delegate = self
        addGestureRecognizer(recognizer)
    }
    
    open override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        if let panGestureRecognizer = gestureRecognizer as? UIPanGestureRecognizer {
            let translation = panGestureRecognizer.translation(in: superview!)
            if abs(translation.x) > abs(translation.y) {
                return true
            }
        }
        return false
    }
    
    func moveViewBackIntoPlace(originalFrame: CGRect) {
        UIView.animate(withDuration: 0.2, animations: {self.frame = originalFrame})
    }
    
    @objc func handlePan(recognizer: UIPanGestureRecognizer) {
        if recognizer.state == .began { originalCenter = center }
        if recognizer.state == .changed { checkIfSwiped(recongizer: recognizer) }
        if recognizer.state == .ended {
            let originalFrame = CGRect(x: 0, y: frame.origin.y,
                width: bounds.size.width, height: bounds.size.height)
            moveViewBackIntoPlace(originalFrame: originalFrame)
        }
    }
    
    func checkIfSwiped(recongizer: UIPanGestureRecognizer) {
        let translation = recongizer.translation(in: self)
        center = CGPoint(x: originalCenter.x + translation.x, y: originalCenter.y)
    }
}

class AbstractPostCellAnimation: AbstractCardCellAnimation{
    var nextId: Int = -1
    var previousId: Int = -1
    var seriesId: Int = -1
    var originalCenter = CGPoint()
    private var isLeftSwipeEnabled = false
    private var isRightSwipeEnabled = false
    var isLeftSwipeSuccessful = false
    var isRightSwipeSuccessful = false
    var delegate: TableViewCellDelegate?
    
    func bootstrap(leftSwipe: Bool, rightSwipe: Bool, nId: Int, pId: Int, sId: Int) {
        isLeftSwipeEnabled = leftSwipe
        isRightSwipeEnabled = rightSwipe
        self.nextId = nId
        self.previousId = pId
        self.seriesId = sId
    }
    
    override func checkIfSwiped(recongizer: UIPanGestureRecognizer) {
        let translation = recongizer.translation(in: self)
        center = CGPoint(x: originalCenter.x + translation.x, y: originalCenter.y)
        isLeftSwipeSuccessful = frame.origin.x > frame.size.width / 4.0
        isRightSwipeSuccessful = frame.origin.x < frame.size.width / 4.0
    }

    func loadCreatePostController() {
        print("loadCreatePostController. series:: \(seriesId) tag:: \(nextId)")
        delegate?.loadCreatePostView(series: seriesId, tag: nextId)
    }
    
    @objc override func handlePan(recognizer: UIPanGestureRecognizer) {
        if recognizer.state == .began { originalCenter = center }
        if recognizer.state == .changed { checkIfSwiped(recongizer: recognizer) }
        if recognizer.state == .ended {
            let originalFrame = CGRect(x: 0, y: frame.origin.y, width: bounds.size.width, height: bounds.size.height)
            if isLeftSwipeEnabled && isRightSwipeEnabled {
                if isLeftSwipeSuccessful {
                    delegate?.hasPerformedSwipe(series: seriesId, tag: previousId)
                } else if isRightSwipeSuccessful {
                    delegate?.hasPerformedSwipe(series: seriesId, tag: nextId)
                } else {
                    moveViewBackIntoPlace(originalFrame: originalFrame)
                }
            } else if isLeftSwipeEnabled {
                if isLeftSwipeSuccessful {
                    delegate?.hasPerformedSwipe(series: seriesId, tag: previousId)
                } else {
                    moveViewBackIntoPlace(originalFrame: originalFrame)
                }
            } else if isRightSwipeEnabled {
                if isRightSwipeSuccessful {
                    delegate?.hasPerformedSwipe(series: seriesId, tag: nextId)
                } else {
                    moveViewBackIntoPlace(originalFrame: originalFrame)
                }
            } else {
                moveViewBackIntoPlace(originalFrame: originalFrame)
            }
        }
    }
}

class MainPostCell: UITableViewCell {
    static let indetifier = "MainPostCell"
    
    @IBOutlet weak var postView: UIView!
    @IBOutlet weak var postText: UITextView!
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var names: UILabel!
    @IBOutlet weak var shareCount: UILabel!
    @IBOutlet weak var replyCount: UILabel!
    @IBOutlet weak var likeCount: UILabel!
    @IBOutlet weak var shareBtn: UIButton!
    @IBOutlet weak var commentBtn: UIButton!
    @IBOutlet weak var likeBtn: UIButton!
    
    var like: Bool = false

    override func awakeFromNib() {
        super.awakeFromNib()
        postText.isScrollEnabled = false
        postText.isEditable = false
        postView.layer.cornerRadius = 16
        userImg.layer.cornerRadius = 27
        postView.tag = -1
        let image = UIImage(named: "conversation_2")
        commentBtn.setImage(image, for: .normal)
        likeBtn.setImage(UIImage(named: "heart"), for: .normal)
        shareBtn.setImage(UIImage(named: "share"), for: .normal)
    }
    
    @IBAction func didTapMPLikeBtn() {
        if !like {
            likeBtn.setImage(UIImage(named: "heart_active"), for: .normal)
            likeBtn.tintColor = .red
            like = true
        } else {
            likeBtn.setImage(UIImage(named: "heart"), for: .normal)
            likeBtn.tintColor = .black
            like = false
        }
    }
}

class ReplyPostCell: AbstractPostCellAnimation {
    static let indetifier = "ReplyPostCell"

    @IBOutlet weak var postView: UIView!
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var names: UILabel!
    @IBOutlet weak var postText: UITextView!
    @IBOutlet weak var leftPost: UIView!
    @IBOutlet weak var rightPost: UIView!
    @IBOutlet weak var likeCount: UILabel!
    @IBOutlet weak var replyCount: UILabel!
    @IBOutlet weak var shareCount: UILabel!
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var commentBtn: UIButton!
    @IBOutlet weak var shareBtn: UIButton!
    
    var like: Bool = false
    var nId: Int = -1
    var pId: Int = -1
    var sId: Int = -1
    var leftSwipe: Bool = false
    var rightSwipe: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        super.initialize()
        postText.isScrollEnabled = false
        postText.isEditable = false
        postView.layer.cornerRadius = 16
        rightPost.layer.cornerRadius = 16
        leftPost.layer.cornerRadius = 16
        userImg.layer.cornerRadius = 27
        postView.tag = -1
        likeBtn.setImage(UIImage(named: "heart"), for: .normal)
        commentBtn.setImage(UIImage(named: "conversation_2"), for: .normal)
        shareBtn.setImage(UIImage(named: "share"), for: .normal)
    }
    
    func setup() {
        super.bootstrap(leftSwipe: leftSwipe, rightSwipe: rightSwipe, nId: postView.tag, pId: pId, sId: sId)
    }
    
    @IBAction func didTapRPLikeButton() {
        if !like {
            likeBtn.setImage(UIImage(named: "heart_active"), for: .normal)
            likeBtn.tintColor = .red
            like = true
        } else {
            likeBtn.setImage(UIImage(named: "heart"), for: .normal)
            likeBtn.tintColor = .black
            like = false
        }
    }
    
    @IBAction func didTapRPCommentBButton() {
        super.loadCreatePostController()
    }
}

class CardsTableViewController: UITableViewController, TableViewCellDelegate {
    private let mc_0: Post = Post(series: 0, id: 0, previous_id:0, username:"Gabrecks", text: "Study: Developers spend almost 2 days a week just waiting for other developers to review their code", mainPost: true)
    private let c1_0: Post = Post(series: 0, id: 1, previous_id:0, username: "wubwub", replyUsername:"Gabrecks\n", text: "Simple! Just work on one person teams. No one else to review the code.",isRightReplySet: true)
    private let c10_0: Post = Post(series: 0, id: 10, previous_id:0, username: "IceSentry", replyUsername:"Gabrecks\n", text: "The article mentioned having trouble finding time between task to do a quick review. That's your issue right there. Reviewing a PR should be a task just as important as creating one. Don't start working on something if there are PRs opened. Starting to work on a new issue is just going to make everything worse and slow down your team even more.\nAnd obviously, encourage small PRs or if it's a big PR at least try to split it in clear commits.", isLeftReplySet: true)
    private let c11_0: Post = Post(series: 0, id: 11, previous_id:0, username: "grauenwolf", replyUsername:"IceSentry\n", text: "Reviewing a PR should be a task just as important as creating one.\nPeople need to understand this. High quality code isn't cheap, especially in the beginning when you're defining the design patterns for the project.\nIf you're lazy with this step, your code will quickly become a big ball of mud.")
    private let c12_0: Post = Post(series: 0, id: 12, previous_id:0, username: "8BitSk8r", replyUsername:"grauenwolf\n", text: "Please tell my coworkers this. They think \"agile\" means \"we don't plan we just react\".", isRightReplySet: true)
    private let c120_0: Post = Post(series: 0, id: 120, previous_id:1, username: "eternaloctober", replyUsername:"grauenwolf\n", text: "That is a toughy since early phase stuff can easily have giant \"this touches everything\" prs. This REQUIRES very clear communication on the PR descriptions...my experience is the avg PR fell way short of being well communicated", isLeftReplySet: true)
    private let c121_0: Post = Post(series: 0, id: 121, previous_id:1, username: "grauenwolf", replyUsername:"eternaloctober\n", text: "True. Sometimes I just ignore the PR and review the end state of the code, creating refactoring tasks rather than dings against the PR.\nAs long as the work is logged, I don't care if it happens in the PR itself.")
    private let c122_0: Post = Post(series: 0, id: 122, previous_id:1, username: "TuckerCarlsonsWig", replyUsername:"grauenwolf\n", text: "“can you refactor this mess while you’re here” is such a shitbag thing to ask in a PR \nBut I always just go along with it because it’s always easier to just put up with every demand than to drag your feet. Ultimately your reviewer is in control and if you want to get something done, you have to appease that person one way or another.")
    private let c123_0: Post = Post(series: 0, id: 123, previous_id:1, username: "roodammy44", replyUsername:"TuckerCarlsonsWig\n", text: "When it’s a monster PR it’s best to sit down together (or over a video) and discuss everything in detail. Otherwise it’s a mostly worthless review", isRightReplySet: true)
    private let c1230_0: Post = Post(series: 0, id: 1230, previous_id:12, username: "progrethth", replyUsername:"TuckerCarlsonsWig\n", text: "That is not a good thing. When I have worked in healthy environments my usual response to such queries is \"no, I feel that refactoring that would make this PR too large\". I like doing refactors when I already am touching a piece of code, but if a reviewer requests of me to do an unreasonably large refactoring I just tell them that I will not let that block the MR. It is perfectly fine to push back against reviewer, you are both supposed to be at the same side working towards the same goals.\nOf course there are occasions where I lack the political power to say no, and then I obviously do the refactoring. But it is bad when people cannot say no.", isLeftReplySet: true)
    private let c1231_0: Post = Post(series: 0, id: 1231, previous_id:12, username: "Asiriya", replyUsername:"progrethth\n", text: "I think the communication point is really important. Sounds like OP is struggling to have difficult conversations with his team, so this kind of thing need to get raised in retrospectives.\nWhen I first joined my current team I went along with everything despite sometimes disagreeing. I raised it in retro and the team was able to agree that sometimes it was frivolous or frustrating and could be handled better.\nNow it’s not a problem, we know each other, have hung out in person and had beers etc. but before that, when the team is still getting to know each other, the retros are invaluable ways to air the unairable.", isRightReplySet: true)
    private let c12310_0: Post = Post(series: 0, id: 12310, previous_id:123, username: "jl2352", replyUsername:"progrethth\n", text: "You are totally right that it's good to be able to do this in a healthy environment.\nI once worked with someone where if you touched any piece of code, he would ask you to clean up that area of the product too. Since you touched it. If you said no, then he would argue the toss. It would go on, and on, and on. It was one of the most toxic developers I had ever worked with.", isLeftReplySet: true)
    
    private let c1232_0: Post = Post(series: 0, id: 1232, previous_id:12, username: "TuckerCarlsonsWig", replyUsername:"Asiriya\n", text: "Let me clarify. It’s generally a refactor that I agree with anyway. So it’s always faster for me to simply do the refactor in that PR (1 hour) than to convince the reviewer that it’s OK to do later (2 code review cycles, which can be a full day or longer, especially if a senior dev is reviewing) - then follow up with another refactor PR anyway. If it’s a change I don’t agree with then for sure I will push back")
    private let c1233_0: Post = Post(series: 0, id: 1233, previous_id:12, username: "puterTDI", replyUsername:"TuckerCarlsonsWig\n", text: "A 1 hour refactor is an appropriate request for a code review imo.")
    private let c1234_0: Post = Post(series: 0, id: 1234, previous_id:12, username: "TuckerCarlsonsWig\n", replyUsername:"puterTDI\n", text: "sometimes. Other times it sucks tacking on an extra hour of work every time you need to do something")
    
    private let c124_0: Post = Post(series: 0, id: 124, previous_id:1, username: "gyroda", replyUsername:"roodammy44\n", text: "I've done this before PR on occasion. I get my WIP once it's in a suitable state and get a second pair of eyes on it to ensure there's not going to be any major \"we need to rewrite the whole thing\" changes before I tidy it up or put in all the cases or whatever. Because I've certainly had to review work before and said \"this is absolutely not fit for purpose, you're gonna need to start more or less from scratch\". I hated to do it and sometimes it was partly my fault (the work should be well defined enough before it's started), so I try to avoid it on my end as much as possible.", isRightReplySet: true)
    private let c1240_0: Post = Post(series: 0, id: 1240, previous_id:12, username: "sabrinajestar", replyUsername:"roodammy44\n", text: "For a big or important PR I would consider some discussion to be essential. The reviewer needs to understand what the goals of the code change are and why the developer thinks this change will address them.", isLeftReplySet: true, isRightReplySet: true)
    private let c12400_0: Post = Post(series: 0, id: 12400, previous_id:124, username: "atilaneves", replyUsername:"roodammy44\n", text: "If it's a monster PR the review should be just one sentence: \"this is too large to review\".In my experience I've never seen a case of \"this can't be broken down into smaller steps\" be anything other than a colossal lack of imagination.", isLeftReplySet: true)
    private let c13_0: Post = Post(series: 0, id: 13, previous_id:0, username: "treenaks", replyUsername:"8BitSk8r\n", text: "If we plan too much it'll become waterfall", isRightReplySet: true)
    private let c130_0: Post = Post(series: 0, id: 130, previous_id:1, username: "Arnold729", replyUsername:"8BitSk8r\n", text: "That a poor point of vue", isLeftReplySet: true)
    private let c131_0: Post = Post(series: 0, id: 131, previous_id:1, username: "State_Space", replyUsername:"Arnold729\n", text: "You can see the angular they're coming from.")
    private let c132_0: Post = Post(series: 0, id: 132, previous_id:1, username: "brightside1999", replyUsername:"State_Space\n", text: "This is node a good thing.")
    private let c133_0: Post = Post(series: 0, id: 133, previous_id:1, username: "ARatherMellowFellow", replyUsername:"brightside1999\n", text: "That's no way to react.")
    private let c134_0: Post = Post(series: 0, id: 134, previous_id:1, username: "four024490502", replyUsername:"ARatherMellowFellow\n", text: "Knockout with these pun threads.")
    private let c135_0: Post = Post(series: 0, id: 135, previous_id:1, username: "ARatherMellowFellow", replyUsername:"four024490502\n", text: "Shoosh, we'll run you out of here on rails.")
    
    private let c14_0: Post = Post(series: 0, id: 14, previous_id:0, username: "46516481168158431985", replyUsername:"treenaks\n", text: "\"writing things down is waterfall\"")
    private let c15_0: Post = Post(series: 0, id: 15, previous_id:0, username: "postblitz", replyUsername:"treenaks\n", text: "\"everything made by waterfall was bad\"")

    private let c2_0: Post = Post(series: 0, id: 2, previous_id:0, username: "webauteur", replyUsername:"wubwub\n", text: "That is how I work. I am the only programmer at my company.")
    private let c3_0: Post = Post(series: 0, id: 3, previous_id:0, username: "MyUsrNameWasTaken", replyUsername:"webauteur\n", text: "Same here. I just push to production and let the end users review")
    private let c4_0: Post = Post(series: 0, id: 4, previous_id:0, username: "B8F1F488", replyUsername:"MyUsrNameWasTaken\n", text: "What if you want them to view more than just the error log each time :D ?", isRightReplySet: true)
    private let c40_0: Post = Post(series: 0, id: 40, previous_id:0, username: "Dreamtrain", replyUsername:"MyUsrNameWasTaken\n", text: "Ahh testing in production, those were simpler times", isLeftReplySet: true, isRightReplySet: true)
    private let c400_0: Post = Post(series: 0, id: 400, previous_id:4, username: "colexian", replyUsername:"MyUsrNameWasTaken\n", text: "Ah, you must be the guy maintaining New World. I am a huge fan of your work.", isLeftReplySet: true)

    private let c5_0: Post = Post(series: 0, id: 5, previous_id:0, username: "cecilkorik", replyUsername:"B8F1F488\n", text: "Why would I want that? Error logs are very easy to render and significantly reduce CPU usage. Big $$$ Savings!", isRightReplySet: true)
    private let c50_0: Post = Post(series: 0, id: 50, previous_id:0, username: "Ooooweee", replyUsername:"B8F1F488\n", text: "Logj4 makes this so easy /s", isLeftReplySet: true)
    
    // ==========================================
    private let mc_1: Post = Post(series: 1, id: 0, previous_id:0, username:"TheLonePawn", text: "Patch fixing critical Log4J 0-day has its own vulnerability that’s under exploit", mainPost: true)
    private let c1_1: Post = Post(series: 1, id: 1, previous_id:0, username: "renatoathaydes", replyUsername:"TheLonePawn\n", text: "I second the \"promoted comment\" in the blog post:\n\"Given that most people using Log4J don't use any of the fancy features that are causing vulnerabilities, I think there's a real case for a simple, well-audited drop-in replacement that just implements the core API methods for lightweight users.\" \nMaybe log4j3? With all the fancy, not-so-thought-out, obscure, niche features relegated to optional modules you need to opt-in to get?")
    private let c2_1: Post = Post(series: 1, id: 2, previous_id:0, username: "TheLonePawn", replyUsername:"renatoathaydes\n", text: "Yes. It's like using Swiss army knife to apply butter. A lot of tools have been bloated trying to do too many things at once.")
    private let c3_1: Post = Post(series: 1, id: 3, previous_id:0, username: "cmccormick", replyUsername:"TheLonePawn\n", text: "It would be nice if more product and library owners knew when to stop adding features. Sometimes the best feature is to drop a less used feature.", isRightReplySet: true)
    private let c30_1: Post = Post(series: 1, id: 30, previous_id:0, username: "Sability", replyUsername:"TheLonePawn\n", text: "But what about that one customer who needs to use a tooth pick to spread butter sometimes? Their needs would go unfulfilled! Or that company that needs to cut through tough buttered toast? We'd lose them!", isLeftReplySet: true)
    private let c31_1: Post = Post(series: 1, id: 31, previous_id:0, username: "immibis", replyUsername:"Sability\n", text: "This is how software evolves: someone wants a feature, they add it. Someone wants a feature, they add it. Someone wants a feature, they add it. Eventually you have too many features, but that is also the reason why everyone uses your software.")
    private let c32_1: Post = Post(series: 1, id: 32, previous_id:0, username: "BlokeInTheMountains", replyUsername:"immibis\n", text: "It's the reason everyone uses your software until the swiss cheese of untestable combinations starts being exploited then everyone moves to something else.", isRightReplySet: true)
    private let c320_1: Post = Post(series: 1, id: 320, previous_id:3, username: "pfp-disciple", replyUsername:"immibis\n", text: "This is how software \"evolves\"", isLeftReplySet: true)
    private let c321_1: Post = Post(series: 1, id: 321, previous_id:3, username: "Stoomba\n", replyUsername:"pfp-disciple\n", text: "This is how software \"evolves\", \"festers\" mutates into unknowable eldritch horrors where we rely on mystic wizards who have knowledge of the beast to keep it from breaking the world.")
    private let c322_1: Post = Post(series: 1, id: 322, previous_id:3, username: "jasoncm", replyUsername:"Stoomba\n", text: "I was waiting for someone to mention sendmail in this thread...")
    private let c323_1: Post = Post(series: 1, id: 323, previous_id:3, username: "constant_void\n", replyUsername:"jasoncm\n", text: "emacs corollary")
    private let c324_1: Post = Post(series: 1, id: 324, previous_id:3, username: "jasoncm", replyUsername:"constant_void\n", text: "I think of emacs less as an unknowable pit from whence eldritch horrors spawn and more of a castle laboratory where a mad scientist steals fire from the gods to power his abominations.")
    
    private let c4_1: Post = Post(series: 1, id: 4, previous_id:0, username: "CathbadTheDruid", replyUsername:"cmccormick\n", text: "A wise person once told me \"features you don't add will never break\".\nThey were right.", isRightReplySet: true)
    private let c40_1: Post = Post(series: 1, id: 40, previous_id:0, username: "TheLonePawn", replyUsername:"cmccormick\n", text: "Good luck marking issues from people telling how their critical code depends on obscure feature as \"won't fix\".\nAlso bonus: https://xkcd.com/1172/", isLeftReplySet: true)
    private let c41_1: Post = Post(series: 1, id: 41, previous_id:0, username: "WTFwhatthehell", replyUsername:"TheLonePawn\n", text: "I honestly think the failure happens when tools are allowed to become too feature-rich.\nAt a certain point it's better to have a second tool.\nThere's few things more frustrating than when an essential tool gets broken by something not being backwards compatible... but a lot of the time it's because someone included a gigantic do-everything tool somewhere in the chain.")
    private let c42_1: Post = Post(series: 1, id: 42, previous_id:0, username: "Stoomba", replyUsername:"WTFwhatthehell\n", text: "This is what you happens when the buyers are not the users and the sellers are not the makers.", isRightReplySet: true)
    private let c420_1: Post = Post(series: 1, id: 420, previous_id:4, username: "hennell", replyUsername:"WTFwhatthehell\n", text: "But if you go too far into single-feature second tool logic, you get into NPM style 'is_odd', 'is_even' packages and dependencies chains as long as 'while true'.", isLeftReplySet: true)

    private let c5_1: Post = Post(series: 1, id: 5, previous_id:0, username: "VeryOriginalName98", replyUsername:"CathbadTheDruid\n", text: "That is some cultured wisdom. Was this wise person one of those fabled philosoraptors?", isRightReplySet: true)
    private let c50_1: Post = Post(series: 1, id: 50, previous_id:0, username: "PhaseSea1141", replyUsername:"CathbadTheDruid\n", text: "The poor badly tested patchwork to add them when the lib doesn't provide what it was needed will tho.", isLeftReplySet: true)
    private let c51_1: Post = Post(series: 1, id: 51, previous_id:0, username: "CathbadTheDruid", replyUsername:"PhaseSea1141\n", text: "I can't control the world. I can only control what I do.\nIf someone else insists on doing something stupid that's on them.")
    private let c52_1: Post = Post(series: 1, id: 52, previous_id:0, username: "PhaseSea1141", replyUsername:"CathbadTheDruid\n", text: "My point is that having set of commonly used features is good as that stops people from reimplementing it badly for 100th time.\nBut on other side that's really something that should be relegated to optional modules.", isRightReplySet: true)
    private let c520_1: Post = Post(series: 1, id: 520, previous_id:5, username: "beejak", replyUsername:"CathbadTheDruid\n", text: "Need to frame that and put it across the wall", isLeftReplySet: true)
    private let c6_1: Post = Post(series: 1, id: 6, previous_id:0, username: "CathbadTheDruid", replyUsername:"VeryOriginalName98\n", text: "Actually it was a guy who used to work on weapons systems. He was very big on: \n* Needs to do exactly what it's supposed to, exactly when and where it's supposed to \n* Never, ever do anything else.\nHe only did it for a few years. Apparently it's really stressful work.\nOTOH, it was a very valuable technique for the stuff I worked on. If I screwed up, nobody would die, but shelves would start to empty out and trucks would stop unloading and I'd get a call @3am and I don't like 3am calls. So I kept my stuff really simple and it didn't break.")
    private let c7_1: Post = Post(series: 1, id: 7, previous_id:0, username: "VeryOriginalName98", replyUsername:"CathbadTheDruid\n", text: "This is the way.")

//    private let mc_1: Card = Card(series: 1, id: 0, previous_id:0, username:"Mr Anderson\n", text: "It should be illegal in the UK to sell a toaster that won’t fit 2 slices of Warburtons toastie without bending", mainPost: true)
//    private let c1_1: Card = Card(series: 1, id: 1, previous_id:0, username: "Morpheus\n", replyUsername:"Mr Anderson\n", text: "Warburtons and Breville teamed up for this problem", isRightReplySet: true)
//    private let c10_1: Card = Card(series: 1, id: 10, previous_id:0, username: "Oracle\n", replyUsername:"Mr Anderson\n", text: "legislation.gov.uk mentions nothing about a Toaster Act, unfortunately.", isLeftReplySet: true)
//    private let c11_1: Card = Card(series: 1, id: 11, previous_id: 1, username: "Agent Smith\n", replyUsername:"Oracle\n", text: "Well it’s time we had one. I’m organising a March to Westminster next Saturday.", isRightReplySet: true)
//    private let c110_1: Card = Card(series: 1, id: 110, previous_id: 1, username:"Mr Anderson\n", replyUsername:"Oracle\n", text: "Perhaps it’s under the Bread and Flour Regulations Act 1998, mate.", isLeftReplySet: true)
//    private let c12_1: Card = Card(series: 1, id: 12, previous_id: 1, username: "Mouse\n", replyUsername:"Agent Smith\n", text: "We should start a Parliamentary Petition online - if they get 100k signatures it'll be debated in Parliament. We'd easily get those from Reddit. We'd also need an undertaking by Warburtons not to sneakily reduce their bread-product sizes in the meantime.")
//    private let c13_1: Card = Card(series: 1, id: 13, previous_id: 1, username: "Agent Jones\n", replyUsername: "Mouse\n", text: ">>We'd also need an undertaking by Warburtons not to sneakily reduce their bread-product sizes in the meantime. \n\nI think just about every food manufacturing company is guilty of that.", isRightReplySet: true)
//    private let c130_1: Card = Card(series: 1, id: 130, previous_id: 1, username: "Rhineheart\n", replyUsername: "Mouse\n", text: "I’d be tempted but change.org has just become a joke with shite petitions about some kid being sent home from a school because of his haircut get 100k votes", isLeftReplySet: true)
//    private let c2_1: Card = Card(series: 1, id: 2, previous_id:0, username: "Trinity\n", replyUsername:"Morpheus\n", text: "It's a shit toaster though. Comes with a cable about a foot long so you better be using that shit right next to a plug socket, and sometimes it doesn't pop things out so just sits there and incinerates it.", isRightReplySet: true)
//    private let c20_1: Card = Card(series: 1, id: 20, previous_id:0, username: "Cypher\n", replyUsername:"Morpheus\n", text: "r/BritishSuccess", isLeftReplySet: true)
//    private let c21_1: Card = Card(series: 1, id: 21, username: "Mr. Rhineheart\n", replyUsername:"Cypher\n", text: "So sweet of Brits that this sub exists and thrives!")
//
//    private let c3_1: Card = Card(series: 1, id: 3, previous_id:0, username:"Switch\n", replyUsername: "Trinity\n", text: "I prefer the side I'll be buttering to be fully toasted and the bottom side to only be done lightly. So yeah, to me that sounds like a feature.", isRightReplySet: true)
//    private let c30_1: Card = Card(series: 1, id: 30, previous_id:0, username:"Tank\n", replyUsername:"Morpheus\n", text: "I get around that by always having at least two slices.", isLeftReplySet: true)
////    ======================================================
    private let mc_2: Post = Post(series: 2, id: 0, previous_id:0, username:"elaehar", text: "The inevitable ice-breakers at work which involve 'interesting' facts about yourself and realising you're quite unremarkable as a person.", mainPost: true)
    private let c1_2: Post = Post(series: 2, id: 1, previous_id:0, username: "Tasty_Trainers", replyUsername:"elaehar\n", text: "I remember that icebreaker when we had to discuss facts with the person sitting next to us and we had to talk about each other's interesting facts. The person asked how old I was, I said 25, and when it was time to report back she told the group I was 35", isRightReplySet: true)
    private let c10_2: Post = Post(series: 2, id: 10, previous_id:0, username: "CatShanks", replyUsername:"elaehar\n", text: "I was at an event once where we had to say one lie and one truth and everyone at the table had to guess. This one guy looked miserable from the start. His lie and truth was \"Hi my name is X and I am happy to be here\"... You only had to look at his name tag to see which one was the lie.", isLeftReplySet: true)
    private let c11_2: Post = Post(series: 2, id: 11, previous_id:0, username: "JasonCZ", replyUsername:"CatShanks\n", text: "This is the type of guy I aspire to be!")

    private let c2_2: Post = Post(series: 2, id: 2, previous_id:0, username: "samzeman", replyUsername:"onestarryeye\n", text: "this is an incredibly funny thing to do", isRightReplySet: true)
    private let c20_2: Post = Post(series: 2, id: 20, previous_id:0, username: "AWilsonFTM", replyUsername:"Tasty_Trainers\n", text: "We once had an interesting variation on this. We were split into groups of 4, and had to come up with unique facts about ourselves. The other members (about an additional 12) then had to work out who it related to. Was actually much more fun than you’d anticipate.", isLeftReplySet: true)
    private let c21_2: Post = Post(series: 2, id: 21, previous_id:1, username: "hanny_991", replyUsername:"AWilsonFTM\n", text: "Oh I've played this game, swapping facts and presenting them to the group. It was an international training about communication so we had a good laugh!")
    private let c22_2: Post = Post(series: 2, id: 22, previous_id:1, username: "AWilsonFTM", replyUsername:"hanny_991\n", text: "Yeah and I remember more about it now. You had to have facts that 2 of you had in common, and then 3 etc etc.")
//    ======================================================
    

    private var seriesArr: Array<CardHashTable<Int, Array<Post>>> = []
    private var seriesState: Array<Int> = []


    private var tableData = [Post]() // viewable data, actuall data stored in the graph loaded into this table
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        var hT0 = CardHashTable<Int, Array<Post>>(capacity: 10000)
        hT0.update(value: [mc_0, c1_0, c2_0, c3_0, c4_0, c5_0], for: 0)
        hT0.update(value: [mc_0, c10_0, c11_0, c12_0, c13_0, c14_0, c15_0], for: 1)
        hT0.update(value: [mc_0, c10_0, c11_0, c120_0, c121_0, c122_0, c123_0, c124_0], for: 12)
        hT0.update(value: [mc_0, c10_0, c11_0, c120_0, c121_0, c122_0, c1230_0, c1231_0, c1232_0, c1233_0, c1234_0], for: 123)
        hT0.update(value: [mc_0, c10_0, c11_0, c120_0, c121_0, c122_0, c1230_0, c12310_0], for: 1231)
        hT0.update(value: [mc_0, c10_0, c11_0, c120_0, c121_0, c122_0, c123_0, c1240_0], for: 124)
        hT0.update(value: [mc_0, c10_0, c11_0, c120_0, c121_0, c122_0, c123_0, c12400_0], for: 1240)
        hT0.update(value: [mc_0, c10_0, c11_0, c12_0,  c130_0, c131_0, c132_0, c133_0, c134_0, c135_0], for: 13)
        hT0.update(value: [mc_0, c1_0, c2_0, c3_0, c40_0], for: 4)
        hT0.update(value: [mc_0, c1_0, c2_0, c3_0, c400_0], for: 40)
        hT0.update(value: [mc_0, c1_0, c2_0, c3_0, c4_0, c50_0], for: 5)

        var hT1 = CardHashTable<Int, Array<Post>>(capacity: 10000)
        hT1.update(value: [mc_1, c1_1, c2_1, c3_1, c4_1, c5_1, c6_1, c7_1], for: 0)
        hT1.update(value: [mc_1, c1_1, c2_1, c30_1, c31_1, c32_1], for: 3)
        hT1.update(value: [mc_1, c1_1, c2_1, c30_1, c31_1, c320_1, c321_1, c322_1, c323_1, c324_1], for: 32)
        hT1.update(value: [mc_1, c1_1, c2_1, c3_1, c40_1, c41_1, c42_1], for: 4)
        hT1.update(value: [mc_1, c1_1, c2_1, c3_1, c40_1, c41_1, c420_1], for: 42)
        hT1.update(value: [mc_1, c1_1, c2_1, c3_1, c4_1, c50_1, c51_1, c52_1], for: 5)
        hT1.update(value: [mc_1, c1_1, c2_1, c3_1, c4_1, c50_1, c51_1, c520_1], for: 52)
        
        var hT2 = CardHashTable<Int, Array<Post>>(capacity: 10000)
        hT2.update(value: [mc_2, c1_2, c2_2], for: 0)
        hT2.update(value: [mc_2, c10_2, c11_2], for: 1)
        hT2.update(value: [mc_2, c1_2, c20_2, c21_2, c22_2], for: 2)
        
//        var hT1 = CardHashTable<Int, Array<Card>>(capacity: 10000)
//        hT1.update(value: [mc_1, c1_1, c2_1, c3_1], for: 0)
//        hT1.update(value: [mc_1, c10_1, c11_1, c12_1, c13_1], for: 1)
//        hT1.update(value: [mc_1, c10_1, c11_1, c12_1, c130_1], for: 13)
//        hT1.update(value: [mc_1, c10_1, c110_1], for: 11)
//        hT1.update(value: [mc_1, c1_1, c20_1, c21_1], for: 2)
//        hT1.update(value: [mc_1, c1_1, c2_1, c30_1], for: 3)
//
//        var hT2 = CardHashTable<Int, Array<Card>>(capacity: 10000)
//        hT2.update(value: [mc_2, c1_2, c2_2], for: 0)
//        hT2.update(value: [mc_2, c10_2, c11_2], for: 1)
//        hT2.update(value: [mc_2, c1_2, c20_2, c21_2, c22_2], for: 2)
        
        seriesArr = [hT0]
//                     , hT1, hT2]
        seriesState = [0]
//                       , 0, 0]
        
        let cards0 = hT0.value(for: 0)
//        let cards1 = hT1.value(for: 0)
//        let cards2 = hT2.value(for: 0)

        cards0?.forEach({ card in
            tableData.append(card)
        })
//        cards1?.forEach({ card in
//            tableData.append(card)
//        })
//        cards2?.forEach({ card in
//            tableData.append(card)
//        })
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    func loadCreatePostView(series: Int, tag: Int) {
        print("Add another view button is clicked. series:: \(series) tag:: \(tag)")
        // Create another UIViewController object.
        let anotherView = CreatePostViewController()
        anotherView.view.backgroundColor = UIColor(red: 0.386491, green: 0.677497, blue: 0.923696, alpha: 1)
        // Present another view object with animation.
        self.present(anotherView, animated: true, completion: nil)
    }
    
    func hasPerformedSwipe(series: Int, tag: Int) {
        print("series: \(series) received tag ::\(tag)")
        fetchData(seriesTag: series, tag: tag)
    }
    
    public func fetchData(seriesTag: Int, tag:Int) {
        var indexPaths: Array<IndexPath> = []
        var arrLength: Int = 0
        var indexCount = 0
        var beforeStack: Array<Post> = []
        var afterStack: Array<Post> = []
        
        if seriesTag > 0 {
            for i in 0...seriesTag - 1  {
                indexCount += (seriesArr[i].value(for: seriesState[i])?.count ?? 0)
                let cards = seriesArr[i].value(for: seriesState[i])!
                beforeStack.append(contentsOf: cards)
            }
        }
        
        let seriesToModify = seriesArr[seriesTag]
        let newCards = seriesToModify.value(for: tag)
        let oldCards = seriesToModify.value(for: seriesState[seriesTag])
        if newCards?.count ?? 0 > oldCards?.count ?? 0 {
            arrLength = (oldCards?.count ?? 0) - 1
        } else {
            arrLength = (newCards?.count ?? 0) - 1
        }
        for i in 0...arrLength  {
            if oldCards?[i] != newCards?[i] {
                indexPaths.append(IndexPath(item: indexCount + i, section: 0))
            }
        }
        
        if seriesTag + 1 <= seriesArr.count - 1 {
            for i in seriesTag + 1...seriesArr.count - 1  {
                let cards = seriesArr[i].value(for: seriesState[i])!
                afterStack.append(contentsOf: cards)
            }
        }
        
        tableData.removeAll()
        beforeStack.forEach({ card in
            tableData.append(card)
        })
        newCards?.forEach({ card in
            tableData.append(card)
        })
        afterStack.forEach({ card in
            tableData.append(card)
        })
        seriesState[seriesTag] = tag
        tableView.reloadData()
//        tableView.insertRows(at: indexPaths, with: .fade)

        
//        tableView.reloadRows(at: indexPaths, with: .fade)
        
//        tableView.reloadRows(at: indexPaths, with: UITableView.RowAnimation.automatic)
    }
    
//    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//        let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, -500, 10, 0)
//        cell.layer.transform = rotationTransform
//        UIView.animate(withDuration: 0.5) {
//            cell.layer.transform = CATransform3DIdentity
//        }
//    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let attrs = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 17)]
        if tableData[indexPath.row].mainPost {
            let cell = tableView.dequeueReusableCell(withIdentifier: MainPostCell.indetifier, for: indexPath) as! MainPostCell
            cell.selectionStyle = .none
            cell.userImg.image = UIImage(named: tableData[indexPath.row].username)
            cell.names.attributedText = getNames(post: tableData[indexPath.row])
            cell.postText.attributedText = NSMutableAttributedString(string: tableData[indexPath.row].text, attributes:attrs)
            cell.postView.tag = tableData[indexPath.row].id
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: ReplyPostCell.indetifier, for: indexPath) as! ReplyPostCell
            cell.delegate = self
            cell.selectionStyle = .none
            cell.userImg.image = UIImage(named: tableData[indexPath.row].username)
            cell.names.attributedText = getNames(post: tableData[indexPath.row])
            cell.postText.attributedText = NSMutableAttributedString(string: tableData[indexPath.row].text, attributes:attrs)
            if tableData[indexPath.row].isLeftReplySet && tableData[indexPath.row].isRightReplySet {
                cell.postView.tag = tableData[indexPath.row].id
                cell.sId = tableData[indexPath.row].series
                cell.pId = tableData[indexPath.row].previous_id
                cell.leftPost.backgroundColor = cell.postView.backgroundColor
                cell.rightPost.backgroundColor = cell.postView.backgroundColor
                cell.rightSwipe = true
                cell.leftSwipe = true
            } else if tableData[indexPath.row].isLeftReplySet {
                cell.postView.tag = tableData[indexPath.row].id
                cell.sId = tableData[indexPath.row].series
                cell.pId = tableData[indexPath.row].previous_id
                cell.rightPost.backgroundColor = tableView.backgroundColor
                cell.leftPost.backgroundColor = cell.postView.backgroundColor
                cell.rightSwipe = false
                cell.leftSwipe = true
            } else if tableData[indexPath.row].isRightReplySet {
                cell.postView.tag = tableData[indexPath.row].id
                cell.sId = tableData[indexPath.row].series
                cell.leftPost.backgroundColor = tableView.backgroundColor
                cell.rightPost.backgroundColor = cell.postView.backgroundColor
                cell.rightSwipe = true
                cell.leftSwipe = false
            } else {
                cell.leftPost.backgroundColor = tableView.backgroundColor
                cell.rightPost.backgroundColor = tableView.backgroundColor
                cell.rightSwipe = false
                cell.leftSwipe = false
            }
            cell.setup()
            return cell
        }
        
    }
    
    func getNames(post: Post) -> NSMutableAttributedString {
        let attrs = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 18)]
        let attributedString = NSMutableAttributedString(string: post.username, attributes:attrs)
        if !post.mainPost {
            let repliedTo = NSMutableAttributedString(string: "\nReplied To ", attributes:[NSAttributedString.Key.font : UIFont.systemFont(ofSize: 18)])
            let replyString = NSMutableAttributedString(string: post.replyUsername, attributes:attrs)
            attributedString.append(repliedTo)
            attributedString.append(replyString)
        }
        return attributedString
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    public struct Post: Encodable, Decodable, Hashable, Identifiable {
        var series: Int
        var id: Int
        var previous_id: Int = -1
        var username: String = ""
        var replyUsername: String = ""
        var text: String = ""
        var isImagePost: Bool = false
        var cellHeight: CGFloat = 0
        var mainPost: Bool = false
        var isLeftReplySet: Bool = false
        var isRightReplySet: Bool = false
    }
}
